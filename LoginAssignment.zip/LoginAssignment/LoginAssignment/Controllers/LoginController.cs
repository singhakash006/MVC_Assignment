﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LoginAssignment.Models;

namespace LoginAssignment.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }

        public List<UserModel> PutValue()
        {
            var users = new List<UserModel>
            {
                new UserModel{id=1,username="Aakash Singh",password="abc@123"},
                new UserModel{id=2,username="Anuj",password="xyz@546"},
                new UserModel{id=3,username="virat",password="uvw@465"},
                new UserModel{id=4,username="Mayank",password="urt@324"}
            };

            return users;
        }

        [HttpPost]
        public IActionResult Verify(UserModel usr)
        {
            var u = PutValue();

            var ue = u.Where(u => u.username.Equals(usr.username));

            var up = ue.Where(p => p.password.Equals(usr.password));

            if(up.Count()==1)
            {
                ViewBag.RedirectUrl = "https://calculator-1.com/simple/"; // External URL
                return View("Login");
            }
            else
            {
                ViewBag.message = "Login Failed";
                return View("Login");
            }
        }
    }
}
